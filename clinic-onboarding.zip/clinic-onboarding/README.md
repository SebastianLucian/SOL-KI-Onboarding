# Voice AI Agent — Clinic Onboarding Form

Interactive onboarding form to collect clinic information for building a custom voice AI agent.

## Setup

```bash
npm install
npm run dev
```

## Deploy on Vercel

1. Push this repo to GitHub
2. Go to vercel.com → Add New Project → Import repo → Deploy
